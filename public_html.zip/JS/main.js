const articles = [
	{
		id: 1,
		title: "لماذا تحرص الدول والمجتمعات على التعليم؟",
		excerpt: "تعرف على أهمية العلم والمعرفة وتأثيرهما على المجتمعات والدول.",
		image: "material/1.jpg",
		link: "Articles/html/index1.html",
	},
	{
		id: 2,
		title: "الفرق بين طريقة نور البيان والطريقة البغدادية ",
		excerpt:
			"الفارق في تأسيس اللغة العربية يكمن في الأسلوب والمنهج المتبع في تعليم اللغة العربية",
		image:
			"material/5.jpg",
		link: "Articles/html/index2.html",
	},
	{
		id: 3,
		title: "انشاء جيل واعي",
		excerpt: " بعض النصائح لمتابعة ولي الأمر لتحصيل أولاده في المواد",
		image: "material/11.jpg",
		link: "Articles/html/index3.html",
	},
	{
		id: 4,
		title: "الفارق بين التعليم الأهلي والتعليم العالمي في السعودية",
		excerpt: "نبذة عن مزايا وعيوب كلا النظامين والاهداف التعليمية لكل منهما",
		image: "material/12.jpg",
		link: "Articles/html/index4.html",
	},
	{
		id: 5,
		title: " طرق لتحسين فهم المقروء في اختبارات القدرات اللفظية",
		excerpt: "نصائح وخطوات لتحسين القدرة علي فهم النص المكتوب",
		image:
			"material/13.jpg",
		link: "Articles/html/index5.html",
	},
	{
		id: 6,
		title: "أفضل نصيحة لمشكلة توتر الطالبات في اختبارات قياس",
		excerpt: "سنتعرف علي اهم الطرق لزيادة الثقة بالنفس والغاء التوتر",
		image: "material/4.jpg",
		link: "Articles/html/index6.html",
	},
	{
		id: 7,
		title: "اختيار المسار في المرحلة الثانوية",
		excerpt: "خطوة حاسمه في تحديد المستقبل ",
		image: "material/1.jpg",
		link: "Articles/html/index7.html",
	},
	{
		id: 8,
		title: "أفضل وسيلة لفهم الرياضيات والتفوق فيها",
		excerpt: "اهم الطرق و العادات التي تجعل منك عقبري في الرياضيات",
		image: "material/3.jpg",
		link: "Articles/html/index8.html",
	},
	{
		id: 9,
		title: "مشكلة حفظ الكلمات والجمل والتراكيب في اللغة الإنجليزية",
		excerpt: "ما هي افضل الطرق و الوسائل لاتقان اللغة الانجليزية",
		image: "material/2.jpg",
		link: "Articles/html/index9.html",
	},
	{
		id: 10,
		title: "فوائد المعلم الخصوصي في المنزل",
		excerpt: "لماذا يجب عليك اتخاذ معلما خصوصيا لأولادك في المنزل ؟",
		image: "material/14.jpg",
		link: "Articles/html/index10.html",
	},
	{
		id: 11,
		title: "عن الحياة الجامعية",
		excerpt: "لماذا تفقد الشغف والحافز في فترة الجامعة ؟",
		image:
			"material/9.jpg",
		link: "Articles/html/index11.html",
	},
	{
		id: 12,
		title: "لماذا يجب عليك المضي قدما بعد المرحلة الثانوية ؟",
		excerpt: "لا تفقد الامل هناك الكثير بانتظارك",
		image: "material/11.jpg",
		link: "Articles/html/index12.html",
	},
	{
		id: 13,
		title: " ما اهمية القدرات اللفظية والكمية ؟",
		excerpt: "ما هي مازايا التميز بقدرات خاصة",
		image: "material/1.jpg",
		link: "Articles/html/index13.html",
	},
	{
		id: 14,
		title: "لماذا اللغة الانجليزية ؟",
		excerpt: "اهمية اللغة الانجليزية في المستقبل الخاص بالابناء",
		image: "material/2.jpg",
		link: "Articles/html/index14.html",
	},
	{
		id: 15,
		title: "ما لغة ال ض ؟",
		excerpt: "اهمية تعلم اللغة العربية بشكل تاسيسي صحيح ",
		image: "material/3.jpg",
		link: "Articles/html/index15.html",
	},
];

document.addEventListener("DOMContentLoaded", function () {
	console.log("صفحة DOM محملة بالكامل");

	const elements = {
		searchBox: document.querySelector(".search-box"),
		articlesContainer: document.getElementById("articles-container"),
		currentYear: document.getElementById("current-year"),
	};
	document.addEventListener("DOMContentLoaded", function () {
		const yearElement = document.getElementById("currentYear");
		if (yearElement) {
			yearElement.textContent = new Date().getFullYear();
		}
	});

	function displayArticles(articlesToDisplay) {
		elements.articlesContainer.innerHTML = "";
		articlesToDisplay.forEach((article) => {
			const articleElement = document.createElement("article");
			articleElement.className = "card animate__animated animate__fadeInUp";
			articleElement.innerHTML = `
			<a href="${article.link}">
				<img src="${article.image}" alt="${article.title}" loading="lazy">
				</a>
				<div class="card-body">
					<h2 class="card-title">${article.title}</h2>
					<p class="card-text">${article.excerpt}</p>
					<a href="${article.link}" class="read-more">اقرأ المزيد</a>
				</div>
				
			`;
			elements.articlesContainer.appendChild(articleElement);
		});
	}

	function searchArticles() {
		const searchTerm = elements.searchBox.value.toLowerCase();
		const filteredArticles = articles.filter(
			(article) =>
				article.title.toLowerCase().includes(searchTerm) ||
				article.excerpt.toLowerCase().includes(searchTerm)
		);
		displayArticles(filteredArticles);
	}

	function debounce(func, wait) {
		let timeout;
		return function (...args) {
			clearTimeout(timeout);
			timeout = setTimeout(() => func.apply(this, args), wait);
		};
	}

	elements.searchBox.addEventListener("input", debounce(searchArticles, 300));

	displayArticles(articles);
});
